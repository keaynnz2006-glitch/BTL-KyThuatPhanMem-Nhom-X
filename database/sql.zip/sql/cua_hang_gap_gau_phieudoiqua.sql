-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cua_hang_gap_gau
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `phieudoiqua`
--

DROP TABLE IF EXISTS `phieudoiqua`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phieudoiqua` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_khach_hang` int NOT NULL,
  `id_nhan_vien_duyet` int DEFAULT NULL,
  `id_gau_muon_doi` int NOT NULL,
  `so_diem_tieu_hao` int NOT NULL,
  `thoi_gian` datetime DEFAULT CURRENT_TIMESTAMP,
  `trang_thai` varchar(50) DEFAULT 'ChoDuyet',
  PRIMARY KEY (`id`),
  KEY `FK_PhieuDoiQua_KhachHang` (`id_khach_hang`),
  KEY `FK_PhieuDoiQua_NhanVien` (`id_nhan_vien_duyet`),
  KEY `FK_PhieuDoiQua_GauBong` (`id_gau_muon_doi`),
  CONSTRAINT `FK_PhieuDoiQua_GauBong` FOREIGN KEY (`id_gau_muon_doi`) REFERENCES `gaubong` (`id`),
  CONSTRAINT `FK_PhieuDoiQua_KhachHang` FOREIGN KEY (`id_khach_hang`) REFERENCES `nguoidung` (`id`),
  CONSTRAINT `FK_PhieuDoiQua_NhanVien` FOREIGN KEY (`id_nhan_vien_duyet`) REFERENCES `nguoidung` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phieudoiqua`
--

LOCK TABLES `phieudoiqua` WRITE;
/*!40000 ALTER TABLE `phieudoiqua` DISABLE KEYS */;
INSERT INTO `phieudoiqua` VALUES (1,1,5,7,10,'2026-07-05 12:31:17','ChoDuyet'),(2,1,5,7,10,'2026-07-05 12:31:20','ChoDuyet'),(3,1,5,7,10,'2026-07-05 12:31:23','ChoDuyet'),(4,1,5,7,10,'2026-07-05 12:37:38','ChoDuyet'),(5,1,5,7,10,'2026-07-05 12:45:39','ChoDuyet'),(6,1,5,7,10,'2026-07-05 12:47:02','ChoDuyet'),(7,1,5,7,10,'2026-07-05 12:47:06','ChoDuyet'),(8,1,5,7,10,'2026-07-05 12:58:23','ChoDuyet'),(9,1,5,7,10,'2026-07-05 13:00:13','ChoDuyet'),(10,1,5,7,10,'2026-07-05 13:00:53','ChoDuyet'),(11,1,5,7,10,'2026-07-05 13:00:58','ChoDuyet'),(12,1,5,7,10,'2026-07-05 13:02:32','ChoDuyet'),(13,1,5,7,10,'2026-07-05 13:03:28','ChoDuyet'),(14,8,5,7,10,'2026-07-05 13:11:22','ChoDuyet'),(15,8,5,7,10,'2026-07-05 13:11:24','ChoDuyet'),(16,9,5,7,10,'2026-07-05 13:44:01','ChoDuyet'),(17,9,5,7,10,'2026-07-05 13:59:51','ChoDuyet'),(19,9,5,7,10,'2026-07-05 14:09:25','ChoDuyet'),(20,8,5,7,10,'2026-07-05 16:19:57','ChoDuyet');
/*!40000 ALTER TABLE `phieudoiqua` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-05 21:29:16
