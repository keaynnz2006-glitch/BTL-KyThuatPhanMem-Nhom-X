-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cua_hang_gap_gau
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gaubong`
--

DROP TABLE IF EXISTS `gaubong`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gaubong` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ten_gau` varchar(100) NOT NULL,
  `hinh_anh` varchar(255) DEFAULT NULL,
  `gia_tri_diem` int DEFAULT '10',
  `so_luong_kho` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1010 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gaubong`
--

LOCK TABLES `gaubong` WRITE;
/*!40000 ALTER TABLE `gaubong` DISABLE KEYS */;
INSERT INTO `gaubong` VALUES (1,'Gấu Trắng Tuyết Bắc Cực','gau_trang.png',1,94),(2,'Gấu Đen Mun Quý Phái','gau_den.png',2,100),(3,'Gấu Trúc Panda Tinh Nghịch','gau_truc.png',3,50),(4,'Mèo Tam Thể May Mắn','meo_tamthe.png',1,120),(5,'Mèo Ba Tư Quý Tộc','meo_batu.png',2,80),(6,'Mèo Anh Lông Ngắn Siêu Cute','meo_aln.png',3,40),(7,'Mèo Siêu Khổng Lồ','meo_khong_lo.png',10,50),(8,'Gấu Siêu Khổng Lồ','gau_khong_lo.png',15,50),(9,'Capybara Siêu Khổng Lồ','capybara_khong_lo.png',20,50);
/*!40000 ALTER TABLE `gaubong` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-05 21:29:16
